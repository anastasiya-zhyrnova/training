﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_6
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Task_1 
            Currency UAH1 = new Currency(340.05);
            Currency UAH2 = new Currency(125.02);
            Currency GBR = new Currency(0.03);
            //string res2 = "" + (UAH1.Add(UAH2));
            //Console.WriteLine(res2);

            //string result = UAH1.Dollars + "." + UAH1.Cents;
            Currency result1 = (UAH1.Add(UAH2));
            //Currency result2 = (UAH2.Multiply(3));
            //result = result2.Dollars + "." + result2.Cents;
            //Console.WriteLine(result1);
            Currency result = GBR.Multiply(50);
            Console.WriteLine(result1.ToString());
            Console.WriteLine(result.ToString());

            #endregion

            #region Task_2

            //Person George_Watson = new Person("George Watson", 45);
            //Person Anna_Quilweber = new Person("Anna Quilweber", 29);

            //Citizen policeman = new Citizen(George_Watson);
            //Citizen officeWorker = new Citizen(Anna_Quilweber);
            //policeman.Id = "3452779";
            //officeWorker.Id = "2324152";

            //LegalPerson taxpayer1 = new LegalPerson();
            //LegalPerson taxpayer2 = new LegalPerson();
            //taxpayer1.Id = "2324152";
            //taxpayer2.Id = "3452779";

            //Bank theBestBank = new Bank();
            //theBestBank.PutMoneyToAccount(officeWorker, 2000);
            //theBestBank.GetMoneyFromAccount(policeman, 30000);
            //theBestBank.GetMoneyFromAccount(officeWorker, 30000);
            //theBestBank.GetMoneyFromAccount(officeWorker, 500);
            //theBestBank.GetAccountBalance(officeWorker);

            //theBestBank.PutMoneyToAccount(taxpayer2, 1500);
            //theBestBank.PutMoneyToAccount(taxpayer1, 3500);
            //theBestBank.GetMoneyFromAccount(taxpayer2, 50);
            //theBestBank.GetAccountBalance(taxpayer1);
            //theBestBank.GetAccountBalance(taxpayer2);

            #endregion

            #region Task_3
            //ILogger fileLogger = new FileLogger("test.txt");
            //ILogger consoleLogger = new ConsoleLogger();

            //List<ILogger> loggersList = new List<ILogger>();
            //loggersList.Add(consoleLogger);
            //loggersList.Add(fileLogger);

            //AggregateLogger loggers = new AggregateLogger(loggersList);
            //loggers.Log("This message will be logged now. First time - in console, second time - in file");

            //Program test = new Program();
            //test.LogHappyMessage(consoleLogger);
            //test.LogHappyMessage(fileLogger);
            //test.LogHappyMessage(loggers);

            #endregion

            Console.ReadKey();
        }

        public void LogHappyMessage(ILogger logger)
        {
            logger.Log("I am happy. I am so happy! :)");
        }
    }
}
