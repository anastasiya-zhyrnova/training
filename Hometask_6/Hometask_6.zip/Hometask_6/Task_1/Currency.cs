﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_6
{
    public class Currency
    {
        public int Dollars { get; private set; }
        public int Cents { get; private set; }

        public Currency()
        {
            Dollars = 0;
            Cents = 0;
        }

        public Currency(int dollars, int cents)
        {
            Dollars = dollars;
            Cents = cents;
        }

        public Currency(double money)
        {
            Dollars = (int)money;
            Cents = (int)Math.Round(((money - Dollars) * 100));
        }

        public double ToDouble()
        {
            double DoubleCents = Convert.ToDouble(Cents) / 100;
            double result = Dollars + DoubleCents;
            return result;
        }

        public Currency Add(Currency money)
        {
            int CentsAdd = this.Cents + money.Cents;
            int DollarsAdd = this.Dollars + money.Dollars + CentsAdd / 100;
            CentsAdd = CentsAdd % 100;
            return new Currency(DollarsAdd, CentsAdd);
        }

        public Currency Multiply(int multiplier)
        {
            int CentsMult = this.Cents * multiplier;
            int DollarsMult = (this.Dollars * multiplier) + CentsMult / 100;
            CentsMult = CentsMult % 100;
            return new Currency(DollarsMult, CentsMult);
        }

        public override string ToString()
        {
            string result = Dollars + ".";

            if (Cents < 10)
            {
                result += "0";
            }
  
            return result + Cents;
        }


    }
}
