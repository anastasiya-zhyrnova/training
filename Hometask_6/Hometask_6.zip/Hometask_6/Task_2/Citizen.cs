﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_6
{
    public class Citizen : Person, IHasId
    {
        public Citizen(Person person) : base (person.Name, person.Age)
        {

        }

        private string _Id;
        public string Id { set { _Id = value; } get { return _Id; } }
    }
}