﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_6
{
    class Bank
    {
        //string - accountHolder Id, int - balance
        private Dictionary<string, int> _bankAccounts = new Dictionary<string, int>();

        public void PutMoneyToAccount(IHasId accountHolder, int quantity)
        {
            if (_bankAccounts.ContainsKey(accountHolder.Id))
            {
                _bankAccounts[accountHolder.Id] += quantity;
            }
            else
            {
                _bankAccounts.Add(accountHolder.Id, quantity);
                Console.WriteLine("New account was created");
            }
        }

        public void GetMoneyFromAccount(IHasId accountHolder, int quantity)
        {
            if (!(_bankAccounts.ContainsKey(accountHolder.Id)))
            {
                Console.WriteLine("This account does not exist");
                return;
            }

            if (_bankAccounts[accountHolder.Id] >=quantity)
            {
                _bankAccounts[accountHolder.Id] -= quantity;
                Console.WriteLine($"{quantity} were succesfully withdrawn");
            }

            else 
            {
                Console.WriteLine("You don't have enough money on your account");
            }
           
        }

        public int? GetAccountBalance(IHasId accountHolder)
        {
            if (_bankAccounts.ContainsKey(accountHolder.Id))
            {
                Console.WriteLine("Your balance is: " + _bankAccounts[accountHolder.Id]);
            }
            return null;


        }
    }
}
