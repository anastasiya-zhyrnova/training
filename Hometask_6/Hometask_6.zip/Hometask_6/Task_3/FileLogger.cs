﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Hometask_6
{
    public class FileLogger : ILogger
    {
        private StreamWriter _streamWriter;

        public FileLogger(string fileName)
        {
            _streamWriter = new StreamWriter(fileName, true);
            _streamWriter.AutoFlush = true;
        }

        public void Log(string text)
        {
            {
                _streamWriter.WriteLine(text);
            }

        }

    }
}
