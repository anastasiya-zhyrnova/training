﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_6
{
    class AggregateLogger : ILogger
    {
        private List<ILogger> _loggers;

        public AggregateLogger(List<ILogger> loggers)
        {
            _loggers = loggers;
        }

        public void Log(string text)
        {
            foreach (ILogger item in _loggers)
            {
                item.Log(text);
            }

        }
    }
}
