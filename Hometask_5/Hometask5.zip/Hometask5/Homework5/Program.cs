﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_5
{
    class Program
    {
        static void Main(string[] args)
        {
            //Task1.GetArray();
            //Task2.GetArray();
            var products = new Dictionary<string, int>
            {
                {"Apple", 10 },
                {"Banana", 15 },
                {"Potato", 200 },
                {"Lemon", 1 },
                {"Tomato", 10 },
                {"Cucumber", 15 }
            };

            var store = new Store(products);
            store.AddClient("Helena Palmer", "1234");
            store.AddClient("Robert Wilson", "qwerty");

            //if (store.Login("Helena Palmer", "1234"))
            //{
            //    store.Buy("Lemon", 1);
            //    store.Buy("Potato", 199);
            //    store.Buy("Lemon", 1);
            //    store.PrintAll(store.GetShoppingCart("Helena Palmer"));
            //    store.Logout();
            //}

            store.Login("Helena Palmer", "dsggsd");
            store.Login("Helena Palmer", "dsggsd");
            store.Login("Helena Palmer", "dsggsd");
            store.GetBannedList();

            //if (store.Login("Robert Wilson", "qwerty"))
            //{
            //    store.PrintAvailableProducts(products);
            //    store.Buy("Lemon", 1);
            //    store.Buy("Tomato", 1);
            //    store.Buy("Tomato", 20);
            //    store.PrintAll(store.GetShoppingCart("Robert Wilson"));
            //    store.Logout();

            //}
            Console.ReadKey();
        }
    }
}
