﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_5
{
    class Task1
    {
        static int[] numsArray = new int[] { 97, 92, 81, 60, 21 };
        //Task 1.
        //Write a program to read n number of values in an array and display it

        public static void GetArray()
        {
            Console.WriteLine(@"Please enter a number to display n numbers of values of array");
            PrintAttentionMessage(numsArray);
            try
            {
                int num = Int32.Parse(Console.ReadLine());
                PrintArray(num, numsArray);
            }
            catch (Exception e)
            {
                Console.WriteLine("ERROR: you have entered not a number or wrong character!");
            }
        }

        public static void PrintAttentionMessage(int[] array)
        {
            int len = array.Length;
            string message = $@"Beware: The length of current array is {len}. You can get an error if
you enter a number that is out of this range";
            Console.WriteLine(message);
        }

        public static void PrintArray(int number, int[] array)
        {
            if ((number < array.Length) && (number >=0))
            {
                for (int i = 0; i < number; i++)
                {
                    Console.WriteLine(array[i]);
                }
            }
            else
                Console.WriteLine(@"ERROR: There are no elements in array corresponding to a number 
that you entered");
        }
    }
}

