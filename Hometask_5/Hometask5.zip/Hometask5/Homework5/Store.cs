﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_5
{
    class Store
    {
        private Dictionary<string, string> _users;
        private Dictionary<string, int> _products;
        private Dictionary<string, Dictionary<string, int>> _shoppingCarts = new Dictionary<string, Dictionary <string, int>>();
        private string loggedUser;
        private int loginTry = 3;
        private List<string> _bannedList = new List<string>();

        public Store(Dictionary<string, int> products)
        {
            _users = new Dictionary<string, string>();
            _products = products;
        }

        public void AddClient(string userName, string password)
        {
            if (!_users.ContainsKey(userName))
            {
                _users.Add(userName, password);
                _shoppingCarts.Add(userName, new Dictionary<string, int>());

            }
        }

        public void PrintAvailableProducts(Dictionary<string, int> products)
        {
            foreach (KeyValuePair<string, int> kvp in products)
            {
                Console.WriteLine("Product - {0}, Amount - {1}", kvp.Key, kvp.Value);
            }
        }

        public bool Login(string userName, string password)
        {
            string loginFail = "You have entered WRONG username or WRONG password. Please try again";
            if (loginTry > 0)
            {
                if (_users.ContainsKey(userName) && _users[userName] == password)
                {
                    loggedUser = userName;
                    Console.WriteLine($@"Welcome to our glocery shop," + "" + GetClientName() + @"! What would you like to buy?
Today we have in our shop:");
                    PrintAvailableProducts(_products);
                    return true;
                }

                else
                {
                    Console.WriteLine(loginFail);
                    loginTry = loginTry-1;
                    Console.WriteLine($"You have {loginTry} attempts to login left");

                    if (loginTry == 0)
                    {
                        Console.WriteLine("Login failed");
                        _bannedList.Add(userName);
                    }

                }

            }
            return false;
        }

        public void GetBannedList()
        {
            Console.WriteLine("---------------");
            Console.WriteLine("BANNED USERS:");
            Console.WriteLine("---------------");
            foreach (string bannedUser in _bannedList)
            {
                Console.WriteLine(bannedUser);
                loggedUser = null;
            }
        }

        public string GetClientName()
        {
            return loggedUser;
        }

        public void Buy(string productName, int amount)
        {
            if (loggedUser!= null)
            {
                Dictionary<string, int> shoppingCart = GetShoppingCart(loggedUser);                
                if ((_products.ContainsKey(productName) && (_products[productName] >= amount)))
                {
                    shoppingCart.Add(productName, amount);
                    _products[productName] = _products[productName] - amount;
                  
                }
                else
                    Console.WriteLine("Sorry, this product is not available today, come back tomorrow!");
            }
        }

        //this method returns shopping cart of specific user mentioned by User Name 
        public Dictionary<string, int> GetShoppingCart(string userName)
        {
            return _shoppingCarts[userName];

        }

        public void PrintAll(Dictionary<string, int> products)
        {
            Console.WriteLine("Currently in shopping cart:");
            foreach (KeyValuePair<string, int> kvp in products)
            {
                Console.WriteLine("Product - {0}, Amount - {1}", kvp.Key, kvp.Value);
            }
        }

        public void Logout()
        {
            Console.WriteLine("Do you want to logout? Please enter Yes or No to complete operation");
            string userInput = Console.ReadLine();
            if (userInput == "Yes")
            {
                _shoppingCarts[loggedUser].Clear();
                loggedUser = null;
                Console.WriteLine("Thanks for shopping with us! See you soon again");
            }
                   
            else if (userInput == "No")
            {
                Console.WriteLine("Good choice! We still have a lot of interesting goods such as:");
                PrintAvailableProducts(_products);
            }

            else Console.WriteLine("You have entered wrong character or phrase!");
             
        }
    }
}
