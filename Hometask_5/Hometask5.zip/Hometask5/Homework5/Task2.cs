﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_5
{
    class Task2
    {
        static int[] numsArray = new int[5] { 97, 92, 81, 60, 21 };
        /*Task 2.
        Write a program to read last n number of values in an array and
        display it*/

        public static void GetArray()
        {
            Console.WriteLine(@"Please enter a number to display n last numbers of values of array");
            try
            {
                int num = Int32.Parse(Console.ReadLine());
                PrintArray(num, numsArray);
            } 
            catch (Exception e)
            {
                Console.WriteLine("ERROR: you have entered not a number or wrong character!");
            }

        }

        public static void PrintArray(int number, int[] array)
        {

            if ((number <= array.Length) && (number > 0))
            {
                for (int i = array.Length - number; i < array.Length; i++)
                {
                    Console.WriteLine(array[i]);
                }
            }
            else
                Console.WriteLine(@"ERROR: There are no elements in array corresponding to a number 
that you entered");
        }
    }
}
