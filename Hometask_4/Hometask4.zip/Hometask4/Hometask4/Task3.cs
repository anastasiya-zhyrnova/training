﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask4
{
    //Task3
    //Write a program to display n terms of natural number and their sum.

    class Task3
    {
        public static void Run()
        {
            Console.WriteLine("Enter a natural number");
            SomeMethod();            

        }
        public static void SomeMethod()
        {
            
            int number = Int32.Parse(Console.ReadLine());
            int sum = 0;
            for (int i = 0; i <= number; i++)
            {
                sum += i;
                Console.WriteLine("number is: " + i);
                Console.WriteLine("current sum is: " + sum + "\n");
            }
            Console.WriteLine("TOTAL SUM IS: " + sum);
        }
    }
}
