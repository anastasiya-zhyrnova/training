﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask4
{
    //Task 4
    //Write program to prompt the user to choose the correct answer from a list.
    //The user can choose to continue answering the question or stop answering it.
    //
    //    What is the color of Banana?
    //    a.Red
    //    b.Green
    //    c.Yellow
    //    d.Blue
    //    e.Purple

    class Task4
    {
        public static void Run()
        {
            doQuestion("What is the color of Banana?", new string[] { "Red", "Green", "Yellow", "Blue", "Purple" }, 2);
        }

        public static void doQuestion(string question, string[] answers, int correctAnswerIndex)
        {
            bool stop = false;
            Console.WriteLine(question);
            Console.WriteLine("Please enter Y to choose option or N to stop answering");

            string correctAnswer = answers[correctAnswerIndex];

            for (int i = 0; i < answers.Length; i++)
            {
                Console.WriteLine(answers[i] + '?');
                string userAnswer = Console.ReadLine();

                if (userAnswer.Equals("N"))
                {
                    stop = true;
                    break;
                }

                else if (userAnswer.Equals("Y"))
                {
                    if (correctAnswerIndex == i)
                    {
                        Console.WriteLine("That is the right answer! Well done!");
                        stop = true;
                    }
                    else
                    {
                        Console.WriteLine("Nope, that is not a right answer :(");
                    }
                }
                else
                {
                    i--;
                }

                if (stop)
                    break;
            }

        }
        
    }
    
}
