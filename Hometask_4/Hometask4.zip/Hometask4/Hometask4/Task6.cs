﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask4
{
    class Task6
    {
        //Task 6
        //You have the natural numbers from 35 to 87. 
        //Write a program that will output all the values in order - 
        //stop outputting when it reaches to 71

        public static void Run()
        {
            PrintNumbers();
        }

        public static void PrintNumbers()
        {
            int[] natNums = new int[100];
            for (int i = 35; i <= 87; i++)
            {
                natNums[i] = i;
                if (natNums[i] == 71)
                    break;                
                Console.WriteLine(natNums[i]);
            }
        }
    }
}
