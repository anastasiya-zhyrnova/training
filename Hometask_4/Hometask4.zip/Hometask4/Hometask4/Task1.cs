﻿using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

namespace Hometask4
{
    public class Task1
    {
        static string[] fruits = new string[]
        {
            "apple",
            "avocado",
            "banana",
            "apricot",
            "jackfruit",
            "cherimoya",
            "papaya",
            "pineapple",
            "lime",
            "lemon",
            "grape",
            "orange",
            "grapefruit",
            "strawberry"
        };

        static string[] fruitsDifCase = new string[]
        {
            "Apple",
            "Avocado",
            "Banana",
            "Apricot",
            "Jackfruit",
            "Cherimoya",
            "Papaya",
            "Pineapple",
            "Lime",
            "Lemon",
            "Grape",
            "Orange",
            "Grapefruit",
            "Strawberry"
        };

        public static void Run()
        {
            //Task 1
            //Please bring the value which are not contains “ap” to the console.

            Console.WriteLine(FruitsCheck("ap"));

            //Optional: How to get the same result as for string array
            //with the same conditions as for previous task?

            Console.WriteLine(FruitsCheckOptional("ap"));
        }

        private static string FruitsCheck(string chars)
        {
            string result = "";

            foreach (string el in fruits)
                result += (!el.Contains(chars)) ? el + "\n" : "";

            return result;
        }

        private static string FruitsCheckOptional(string chars)
        {
            string result = "";

            foreach (string el in fruitsDifCase)
                result += (!el.ToLower().Contains(chars)) ? el + "\n" : "";

            return result;
        }
    }
}
