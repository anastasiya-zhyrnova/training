﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask4
{
    class Task2
    {
        //Task 2
        //Write a program, which can find a sum of 1 + 2 + 3 + ... + n, 
        //where n number entered from the keyboard by the user.

        public static void Run()
        {
            Console.WriteLine(StartMessage());
            int userInputNumber;
            string userInp = Console.ReadLine();
            bool isSuccess = Int32.TryParse(userInp, out userInputNumber);

            if (isSuccess)
            {
                Console.WriteLine(GetNumSum(userInputNumber));
                Console.ReadLine();
            }
            else
                Console.WriteLine("You have entered not a number!");
        }

        public static string StartMessage()
        {
            return "Please enter some number to get a sum of 1 + 2 + 3 + ... + n, where n is your number";
        }

        public static int GetNumSum(int userInp)
        {
            int res = 0;
            for (int i = userInp; i > 0; i--)
            {
                res += i;
            }
            return res;
        }

        //Using the formula for the first n terms of an arithmetic sequence, starting with i = 1:
        public static int GetNumSumViaFormula (int userInp)
        {
            int res = 0;
            res = ((1 + userInp) * userInp) / 2;
            return res;
        }
    }
}
