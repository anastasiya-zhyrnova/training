﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Task1.Run();

            //Task2.Run();

            //Task3.Run();

            Task4.Run();

            //Task5.Run();

            //Task6.Run();       

            Console.ReadKey();
        }
    }
}
