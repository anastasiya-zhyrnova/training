﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask4
{
    class Task5
    {
        //Task 5
        //Write a program that will "ask" the correct password, as long as it is entered. 
        //The correct password will be the «root».

        public static void Run()
        {
            Console.WriteLine(PasswordCheck());
            Console.ReadKey();
        }

        public static string PasswordCheck()
        {
            string userInput;
            string welcomeMessage = "That is the right password! Welcome!";
            string rightPassword = "root";
            do
            {
                Console.WriteLine("Please enter the password");
                userInput = Console.ReadLine();
            } while (userInput != rightPassword);
            return welcomeMessage;
        }
           
    }
}

