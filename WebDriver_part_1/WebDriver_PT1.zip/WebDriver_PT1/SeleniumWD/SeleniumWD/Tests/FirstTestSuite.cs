﻿using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumWD.Core;
using SeleniumWD.Steps;

namespace SeleniumWD.Tests
{ 
    [TestFixture]
    public class FirstTestSuite
    {
        private IWebDriver _driver;
        private const string Url = "https://www.citrus.ua/";

        [OneTimeSetUp]
        public void Setup()
        {
            _driver = SeleniumDriver.Driver;
            _driver.Manage().Window.Maximize();
        }

        [Test]
        public void SearchForMacbook_ShouldReturnMacbooks()
        {
            _driver.Url = Url;

            var homePage = new HomePageSteps(_driver);
            var resultPage = new SearchResultPageSteps(_driver);

            homePage.Search("macbook");
           

            var resultList = resultPage.GetResultItemTitle().ToList();
            Assert.IsTrue(resultList.All(i => i.Contains("MacBook")));

            
        }

        [Test]
        public void SearchForLGTV_ShouldDisplayAllLGTVs()
        {
            _driver.Url = Url;

            var homePage = new HomePageSteps(_driver);

            //homePage.ClosePopup(); works without that, my tests just ignore popups
            homePage.NavigateToLG();
            
            var resultPage = new SearchResultPageSteps(_driver);
            var resultList = resultPage.GetResultItemTitle().ToList();
            Assert.IsTrue(resultList.All(i => i.Contains("LG")));
        }

        [Test]
        public void FilterPill_ShouldDisplayLGFilterPill()
        {
            _driver.Url = Url;

            var homePage = new HomePageSteps(_driver);

            //homePage.ClosePopup();
            homePage.NavigateToLG();

            var resultPage = new SearchResultPageSteps(_driver);
            string filterText = resultPage.GetFilterText();
            Assert.AreEqual("LG", filterText);
        }

        [Test]
        public void FirstItemName_IsCorrect()
        {
            _driver.Url = Url;
            var homePage = new HomePageSteps(_driver);

            homePage.ClickOnTV();
            var resultPage = new SearchResultPageSteps(_driver);

            var firstItemTitle = resultPage.GetFirstItemTitle();
            var firstItemPrice = resultPage.GetFirstItemPrice();

            Assert.AreEqual("KIVI 24HK30B", firstItemTitle);
            Assert.AreEqual("4 999", firstItemPrice);
        }

        [Test]
        public void CheckFiltersOrder()
        {
            _driver.Url = Url;
            
            var homePage = new HomePageSteps(_driver);
            homePage.ClickOnTV();

            List<string> expectedFilters = new List<string>
            {
                "Цена",
                "Акции и скидки",
                "Бренд",
                "Диагональ",
                "Разрешение",
                "Тип телевизора",
                "Smart TV",
                "Поддержка 3D",
                "Изогнутый экран",
                "Суммарная мощность динамиков",
                "Операционная система"

            };
                
           var resultPage = new SearchResultPageSteps(_driver);
           var filtersList = resultPage.GetFiltersList().ToList();

           Assert.AreEqual(expectedFilters, filtersList);
        }

        [OneTimeTearDown]
        public void TearDown()
        {
            _driver.Quit();
        }
    }
}
