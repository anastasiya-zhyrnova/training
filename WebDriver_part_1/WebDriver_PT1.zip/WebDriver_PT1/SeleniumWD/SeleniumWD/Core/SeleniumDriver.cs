﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumWD.Core
{
    public static class SeleniumDriver
    {
        private static IWebDriver _driver;

        public static IWebDriver Driver
        {
            get
            {
                if (_driver == null)
                {
                    //tried to disable notifications
                    ChromeOptions options = new ChromeOptions();
                    options.AddArguments("--disable-notifications");
                    _driver = new ChromeDriver(options);
                }
                return _driver;
            }

            set { _driver = value; }
        }

        
    }
}
