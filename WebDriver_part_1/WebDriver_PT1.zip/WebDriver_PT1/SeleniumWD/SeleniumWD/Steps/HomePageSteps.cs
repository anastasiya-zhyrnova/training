﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumWD.Pages;

namespace SeleniumWD.Steps
{
    public class HomePageSteps
    {
        private readonly IWebDriver _driver;
        private readonly HomePage _homePage;

        public HomePageSteps(IWebDriver driver)
        {
            _driver = driver;
            _homePage = new HomePage(_driver);
        }

        public void Search(string searchText)
        {
            _homePage.SearchField.SendKeys(searchText);
            _homePage.SearchField.Submit();
        }

        public void NavigateToLG()
        {
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementExists(By.XPath(".//*[@title='TV']")));
            Actions action = new Actions(_driver);
            action.MoveToElement(_homePage.TVMenuItem).Build().Perform();
            var LGElement = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(".//*[@title='LG']")));
            LGElement.Click();

            Thread.Sleep(1000); //:( 
         
        }

        public void ClickOnTV()
        {
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementExists(By.XPath(".//*[@title='TV']")));
            _homePage.TVMenuItem.Click();

            Thread.Sleep(5000); //:(
        }

        public void ClosePopup()
        {
            //my sad attempts
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));
            if (_homePage.MarketingModal.Displayed)
            {
                Actions action = new Actions(_driver);
                action.MoveToElement(_homePage.MarketingModal).MoveToElement(_homePage.CloseButton).Click().Build().Perform();
            }
            
            
        }


    }
}
