﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using SeleniumWD.Pages;

namespace SeleniumWD.Steps
{
    public class SearchResultPageSteps
    {
        private readonly IWebDriver _driver;
        private readonly SearchResultPage _searchPage;

        public SearchResultPageSteps(IWebDriver driver)
        {
            _driver = driver;
            _searchPage = new SearchResultPage(_driver);
        }

        //Version 1
        //public string[] GetResultItemTitle()
        //{
        //    List<string> list = new List<string>();
        //    foreach (IWebElement el in _searchPage.ItemTitles)
        //    {
        //        list = _searchPage.ItemTitles.Select(i => i.GetAttribute("title")).ToList();
        //    }
        //    return list.ToArray();
        //    //return list;
        //    //return _searchPage.ItemTitles.Select(i => i.Text).ToArray();
        //}

        public IEnumerable<string> GetResultItemTitle()
        {
            return _searchPage.ItemTitles.Select(i => i.GetAttribute("innerText"));
        }

        public string GetFirstItemTitle()
        {
            return _searchPage.FirstElement.Text;
        }

        public string GetFirstItemPrice()
        {
            return _searchPage.FirstElementPrice.Text;
        }

        public IEnumerable<string> GetFiltersList()
        {
            return _searchPage.Filters.Select(i => i.Text);
        }


        public void OpenItem(string name)
        {
            var element = _searchPage.ItemTitles.First(i => i.Text.Contains(name));
            element.Click();
        }

        public string GetTitle()
        {
            return _driver.Title;
        }

        public void SelectFilterItem(string filterSection, string filterItem)
        {
            var elementList = GetFilterSection(filterSection).FindElements(By.CssSelector("li a"));
            var filter = elementList.First(i=>i.Text.Contains(filterItem));
            filter.Click();
        }

        private IWebElement GetFilterSection(string name)
        {
            return _searchPage.Properties.First(i => i.Text.Contains(name));
        }

        public string GetFilterText()
        {
            return _searchPage.BrandFilter.Text;
        }
    }
}
