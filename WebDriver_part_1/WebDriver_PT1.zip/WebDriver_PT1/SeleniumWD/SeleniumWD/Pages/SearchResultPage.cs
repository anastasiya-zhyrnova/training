﻿using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;

namespace SeleniumWD.Pages
{
    public class SearchResultPage
    {
        private readonly IWebDriver _driver;

        public SearchResultPage(IWebDriver driver)
        {
            _driver = driver;
        }
        
        public List<IWebElement> ItemTitles => _driver.FindElements(By.CssSelector(".title-itm h5")).ToList();

        public IWebElement FirstElement => _driver.FindElement(By.XPath("//div[contains(@class, 'title-itm')][1]/h5"));

        public IWebElement FirstElementPrice => _driver.FindElement(By.XPath("//*[contains(@class, 'base-price')][1]/span[1]"));

        public IWebElement[] Properties => _driver.FindElements(By.ClassName("properties_block")).ToArray();

        public IWebElement BrandFilter => _driver.FindElement(By.XPath("//span[@title='Бренд']"));

        public List<IWebElement> Filters => _driver.FindElements(By.CssSelector(".filter-itm h3")).ToList();

    }
}
