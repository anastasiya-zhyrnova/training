﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium.Chrome;

namespace SeleniumWD.Pages
{
    public class HomePage
    {
        private readonly IWebDriver _driver;

        public HomePage(IWebDriver driver)
        {
            _driver = driver;
        }

        public IWebElement SearchField => _driver.FindElement(By.Id("multisearch"));
        
        public IWebElement TVMenuItem => _driver.FindElement(By.XPath(".//*[@title='TV']"));
 
        public IWebElement CitrusClubPopup => _driver.FindElement(By.ClassName("iphone-form-block"));
        public IWebElement CloseButton => _driver.FindElement(By.ClassName("el-dialog__headerbtn"));
        public IWebElement MarketingModal => _driver.FindElement(By.Id("marketing-modal-397"));

    }

}
