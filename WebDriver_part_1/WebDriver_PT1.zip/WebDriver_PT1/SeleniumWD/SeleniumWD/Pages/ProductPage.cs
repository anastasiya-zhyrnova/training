﻿using System.ComponentModel.Design;
using OpenQA.Selenium;

namespace SeleniumWD.Pages
{
    public class ProductPage
    {
        private readonly IWebDriver _driver;

        public ProductPage(IWebDriver driver)
        {
            _driver = driver;
        }

        public IWebElement ProductElement =>
            _driver.FindElement((By.CssSelector((".catalog-item .card-product-link .title-itm"))));
        public IWebElement ProductTitle => _driver.FindElement(By.CssSelector(".roww.catalog-roww .stick-container + a"));

        public IWebElement ActiveFilter => _driver.FindElement(By.ClassName(" .catalog-selected"));
    }
}
