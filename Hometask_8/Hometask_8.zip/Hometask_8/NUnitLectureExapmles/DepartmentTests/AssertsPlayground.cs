﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hometask;
using NUnit.Framework;

namespace DepartmentTests
{
    class AssertsPlayground
    {
        [Test]
        public void CheckStrings_ShouldBeEqual_ConstraintModel()
        {
            string actualString = "Hello, World!";

            string expectedString = "hello, world!";

            Assert.That(actualString, Does.Contain("hello, world!").IgnoreCase);
        }

        [Test]
        public void CheckStrings_ShouldBeEqual_StandardModel()
        {
            string actualString = "Hello, World!";

            string expectedString = "hello, world!";

            StringAssert.AreEqualIgnoringCase(expectedString, actualString);

        }

        [Test]
        public void CheckStrings_SubsetOf_StandardModel()
        {
            string actualString = "Hello, World!";
            string shortString = "Hello";

            StringAssert.Contains(shortString, actualString);
        }

        [Test]
        public void CheckStrings_SubsetOf_ConstraintModel()
        {
            string actualString = "Hello, World!";
            string shortString = "Hello";

            Assert.That(shortString, Is.SubsetOf(actualString));
        }

        [Test]
        public void CheckStrings_StartsWith_StandardModel()
        {
            string actualString = "Hello, World!";
            string shortString = "Hell";

            StringAssert.StartsWith(shortString, actualString);
        }

        [Test]
        public void CheckStrings_StartsWith_ConstraintModel()
        {
            string actualString = "Hello, World!";

            Assert.That(actualString.StartsWith("Hello"));
        }

        [Test]
        public void CheckStrings_EndsWith_StandardModel()
        {
            string actualString = "Hello, World!";
            string shortString = "orld!";

            StringAssert.EndsWith(shortString, actualString);
        }

        [Test]
        public void CheckStrings_EndsWith_ConstraintModel()
        {
            string actualString = "Hello, World!";

            Assert.That(actualString.EndsWith("!"));
        }

        [Test]
        public void ArrayCheck_HasZero_StandardModel()
        {
            int[] intArray = new int[] { 55, 88, -2, 25, 6, 0 };

            Assert.Zero(intArray[5]);

        }

        [Test]
        public void ArrayCheck_HasZero_ConstraintModel()
        {
            int[] intArray = new int[] { 55, 88, -2, 25, 6, 0 };

            Assert.That(intArray, Has.Exactly(1).Zero);

        }

        [Test]
        public void ArrayCheck_MultipleAssert_StandardModel()
        {
            int[] intArray = new int[] { 55, 88, -2, 25, 6, 0 };

            int moreThanNum = 0;

            Assert.Multiple(() =>
            {
                Assert.Negative(intArray[2]);
                Assert.Greater(intArray[1], moreThanNum);
                Assert.Negative(intArray[2]);


            });
        }

        [Test]
        public void ArrayCheck_MultipleAssert_ConstraintModel()
        {
            int[] intArray = new int[] { 55, 88, -2, 25, 6, 0 };

            Assert.That(intArray, Has.Exactly(1).Zero);

            Assert.Multiple(() =>
            {
                Assert.That(intArray, Has.Exactly(4).GreaterThan(0));
                Assert.That(intArray, Has.Exactly(1).LessThan(-1));
            });
        }

        [Test]
        public void ListCheck_AreUnique_StandardModel()
        {
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5 };
            Assert.AreNotEqual(numbers[0], numbers[1]);
        }

        [Test]
        public void ListCheck_AreUnique_ConstraintModel()
        {
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5 };
            Assert.That(numbers, Is.Unique);
        }

        [Test]
        public void ListCheck_AreGreaterThan0_StandardModel()
        {
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5 };
            int moreThanNum = 0;
            Assert.Greater(numbers[0], moreThanNum);
            Assert.Greater(numbers[1], moreThanNum);
            Assert.Greater(numbers[2], moreThanNum);
        }

        [Test]
        public void ListCheck_AreGreaterThan0_ConstraintModel()
        {
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5 };
            Assert.That(numbers, Is.All.GreaterThan(0));
        }

        [Test]
        public void ListCheck_AreAllNotNull_StandardModel()
        {
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5 };
            Assert.NotNull(numbers);
        }

        [Test]
        public void ListCheck_AreAllNotNull_ConstraintModel()
        {
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5 };
            Assert.That(numbers, Has.All.Not.Null);
        }

        [Test]
        public void ListCheck_AreAllNotSubsetOf_StandardModel()
        {
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5 };
            List<int> otherNumbers = new List<int>() { 7, 8, 9 };
            Assert.AreNotSame(numbers, otherNumbers);

        }

        [Test]
        public void ListCheck_AreAllNotSubsetOf_ConstraintModel()
        {
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5 };
            List<int> otherNumbers = new List<int>() { 7, 8, 9 };
            Assert.That(otherNumbers, Is.Not.SubsetOf(numbers));
        }

        [Test]
        public void DictionaryCheck_AreUnique_StandardModel()
        {
            Dictionary<int, string> students = new Dictionary<int, string>();
            students.Add(1, "John Snow");
            students.Add(2, "Snow White");
            students.Add(3, "Walter White");

            CollectionAssert.AllItemsAreUnique(students);
        }

        [Test]
        public void DictionaryCheck_AreUnique_ConstraintModel()
        {
            Dictionary<int, string> students = new Dictionary<int, string>();
            students.Add(1, "John Snow");
            students.Add(2, "Snow White");
            students.Add(3, "Walter White");

            Assert.That(students, Is.Unique);
        }

        [Test]
        public void DictionaryCheck_HasCount3_StandardModel()
        {
            Dictionary<int, string> students = new Dictionary<int, string>();
            students.Add(1, "John Snow");
            students.Add(2, "Snow White");
            students.Add(3, "Walter White");

            int expectedCount = 3;

            Assert.AreEqual(expectedCount, students.Count);
        }

        [Test]
        public void DictionaryCheck_HasCount3_ConstraintModel()
        {
            Dictionary<int, string> students = new Dictionary<int, string>();
            students.Add(1, "John Snow");
            students.Add(2, "Snow White");
            students.Add(3, "Walter White");

            Assert.That(students, Has.Exactly(3).Items);
        }

        [Test]
        public void Cars_ShouldBeSortedByColor_StandardModel()
        {
            List<Car> cars = new List<Car>
            {
                { new Car() {Name = "Ford", Color = "Grey", Speed = 100}},
                { new Car() {Name = "Opel", Color = "Red", Speed = 90}},
                { new Car() {Name = "Alpha Romeo", Color = "Blue", Speed = 125}}
            };

            List<Car> expectedCars = new List<Car>
            {
                { new Car() {Name = "Alpha Romeo", Color = "Blue", Speed = 125}},
                { new Car() {Name = "Ford", Color = "Grey", Speed = 100}},
                { new Car() {Name = "Opel", Color = "Red", Speed = 90}},

            };

            cars.Sort();
          
            CollectionAssert.AreEqual(expectedCars, cars);

        }

        [Test]
        public void Cars_ShouldBeSortedByColor_ConstraintModel()
        {
            List<Car> cars = new List<Car>
            {
                { new Car() {Name = "Ford", Color = "Grey", Speed = 100} },
                { new Car() {Name = "Opel", Color = "Red", Speed = 90}},
                { new Car() {Name = "Alpha Romeo", Color = "White", Speed = 125} }
            };

            List<Car> expectedCars = new List<Car>
            {
                { new Car() {Name = "Alpha Romeo", Color = "Blue", Speed = 125}},
                { new Car() {Name = "Ford", Color = "Grey", Speed = 100}},
                { new Car() {Name = "Opel", Color = "Red", Speed = 90}},

            };

            cars.Sort();

            Assert.That(cars, Is.Ordered.By("Color"));
        }

        [Test]
        public void Cars_ShouldBeNotEmpty_StandardModel()
        {
            List<Car> cars = new List<Car>
            {
                { new Car() {Name = "Ford", Color = "Grey", Speed = 100} },
                { new Car() {Name = "Opel", Color = "Red", Speed = 90}},
                { new Car() {Name = "Alpha Romeo", Color = "White", Speed = 125} }
            };

            CollectionAssert.IsNotEmpty(cars);
        }

        [Test]
        public void Cars_ShouldBeNotEmpty_ConstraintModel()
        {
            List<Car> cars = new List<Car>
            {
                { new Car() {Name = "Ford", Color = "Grey", Speed = 100} },
                { new Car() {Name = "Opel", Color = "Red", Speed = 90}},
                { new Car() {Name = "Alpha Romeo", Color = "White", Speed = 125} }
            };

            Assert.That(cars, Is.Not.Empty);
        }

        [Test]
        public void Cars_ShouldBeSortedBySpeedIfColorIsTheSame_StandardModel()
        {
            List<Car> cars = new List<Car>
            {
                { new Car() {Name = "Ford", Color = "Black", Speed = 100} },
                { new Car() {Name = "Opel", Color = "Black", Speed = 90}},
                { new Car() {Name = "Alpha Romeo", Color = "Black", Speed = 125} }
            };

            List<Car> expectedCars = new List<Car>
            {
                { new Car() {Name = "Alpha Romeo", Color = "Black", Speed = 125}},
                { new Car() {Name = "Ford", Color = "Black", Speed = 100}},
                { new Car() {Name = "Opel", Color = "Black", Speed = 90}},

            };

            cars.Sort();

            CollectionAssert.AreEqual(expectedCars, cars);
        }

        [Test]
        public void Cars_ShouldBeSortedBySpeedIfColorIsTheSame_ConstraintModel()
        {
            List<Car> cars = new List<Car>
            {
                { new Car() {Name = "Ford", Color = "Black", Speed = 100} },
                { new Car() {Name = "Opel", Color = "Black", Speed = 90}},
                { new Car() {Name = "Alpha Romeo", Color = "Black", Speed = 125} }
            };

            List<Car> expectedCars = new List<Car>
            {
                { new Car() {Name = "Alpha Romeo", Color = "Black", Speed = 125}},
                { new Car() {Name = "Ford", Color = "Black", Speed = 100}},
                { new Car() {Name = "Opel", Color = "Black", Speed = 90}},

            };

            cars.Sort();

            Assert.That(cars, Is.EqualTo(expectedCars));
            //Assert.That(cars, Is.Ordered.By("Color").Then.By("Speed"));
        }
    }
}
