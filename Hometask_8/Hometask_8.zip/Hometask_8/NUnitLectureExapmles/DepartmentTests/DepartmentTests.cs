﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Hometask;


namespace DepartmentTests
{
    [TestFixture]
    public class DepartmentTests
    {
        Department testDep;

        [SetUp]
        public void CreateDepartment()
        {
            testDep = new Department();
        }

        [TearDown]
        public void DepartmentIsClear()
        {
            testDep = null;
        }

        [Test]
        public void Add_ValidData_ListOfEmployeesShouldHave1Employee()
        {
            Employee PM = new Programmer("Patrick", "Wattington", 55);

            testDep.Add(PM);

            int expectedSize = 1;
            Assert.That(testDep.GetAll().Count, Is.EqualTo(expectedSize));
        }

        [Test]
        public void Add_ValidData_ShouldContainSpecificEmployee()
        {
            Employee deliveryManager = new Manager("Fred", "Watson", 35);

            testDep.Add(deliveryManager);

            Employee expectedEmployee = new Manager("Fred", "Watson", 35);
            var firstElement = testDep.GetAll().ElementAt(0);
            var expectedFirstName = expectedEmployee.FirstName;
            var expectedSurname = expectedEmployee.LastName;
            var expectedAge = expectedEmployee.Age;

            Assert.Multiple(() =>
            {
                Assert.AreEqual(expectedFirstName, firstElement.FirstName);
                Assert.AreEqual(expectedSurname, firstElement.LastName);
                Assert.AreEqual(expectedAge, firstElement.Age);

            });
        }

        [Test]
        public void Add_ShouldThrowNullReferenceException()
        {
            Employee PM = null;
            Assert.Throws<NullReferenceException>(() => testDep.Add(PM));
        }

        [Test]
        public void Sort_ShouldSortByAge()
        {
            Employee javaDev = new Programmer("Ron", "Johnson", 25);
            Employee pythonDev = new Programmer("Isabella", "Johnson", 21);
            Employee manager = new Programmer("Patrick", "Wattington", 55);
            testDep.Add(javaDev);
            testDep.Add(pythonDev);
            testDep.Add(manager);
            testDep.Sort();

            List<Employee> expectedCollection = new List<Employee> { pythonDev, javaDev, manager };

            Assert.That(testDep.GetAll(), Is.EqualTo(expectedCollection));

        }

        [Test]
        public void Sort_SameAgeSameSurname_DoesNotSortIfSurnamesAndAgeAreTheSame()
        {
            Employee javaDev = new Programmer("Richard", "Johnson", 21);
            Employee pythonDev = new Programmer("Anna", "Johnson", 21);

            testDep.Add(javaDev);
            testDep.Add(pythonDev);
            testDep.Sort();

            List<Employee> expectedCollection = new List<Employee> { javaDev, pythonDev };

            Assert.That(testDep.GetAll(), Is.EqualTo(expectedCollection));

        }

        [Test]
        public void GetAll_ValidData_ShouldContain3Employees()
        {
            List<Employee> employees = new List<Employee>();
            Employee javaDev = new Programmer("Ron", "Johnson", 25);
            Employee pythonDev = new Programmer("Isabella", "Johnson", 21);
            Employee manager = new Programmer("Patrick", "Wattington", 55);
            testDep.Add(javaDev);
            testDep.Add(pythonDev);
            testDep.Add(manager);

            foreach (Employee emp in employees)
            {
                testDep.Add(emp);
            }

            int expectedCount = 3;
            Assert.AreEqual(expectedCount, testDep.GetAll().Count);
        }

        

    }
}




