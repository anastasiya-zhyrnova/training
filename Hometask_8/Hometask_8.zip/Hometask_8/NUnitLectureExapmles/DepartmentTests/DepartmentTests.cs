﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Hometask;


namespace DepartmentTests
{
    [TestFixture]
    public class DepartmentTests
    {
        //[SetUp]
        //public void SetUp()
        //{
        //    how make it a precondition ??
        //    Department testDep = new Department();
        //}

        [Test]
        public void Add_ValidData_ListOfEmployeesShouldHave1Employee()
        {
            //arrange
            //Department testDep = new Department();
            List<Employee> testEmployees = new List<Employee>();
            Employee PM = new Programmer("Patrick", "Wattington", 55);


            //act
            testEmployees.Add(PM);
            int expectedSize = 1;

            //assert
            Assert.That(testEmployees, Has.Count.EqualTo(expectedSize));
        }

        [Test]
        public void Add_ValidData_ShouldContainSpecificEmployee()
        {
            //arrange
            List<Employee> testEmployees = new List<Employee>();
            Employee deliveryManager = new Manager("Fred", "Watson", 35);

            //act
            testEmployees.Add(deliveryManager);
            Employee expectedEmployee = new Manager("Fred", "Watson", 35);
            var firstElement = testEmployees.ElementAt(0);
            var expectedFirstName = expectedEmployee.FirstName;
            var expectedSurname = expectedEmployee.LastName;
            var expectedAge = expectedEmployee.Age;


            //assert
            Assert.AreEqual(expectedFirstName, firstElement.FirstName);
            Assert.AreEqual(expectedSurname, firstElement.LastName);
            Assert.AreEqual(expectedAge, firstElement.Age);
            //Assert.Contains(expectedEmployee, testEmployees);
            //Assert.AreEqual(expectedEmployee, firstElement);

        }

        [Test]
        //[ExpectedException(typeof(NullReferenceException)), ExpectedMessage = "smt"]
        public void Add_Null_ShouldThrowException()
        {
            //arrange
            Department testDep = new Department();
            List<Employee> testEmployees = new List<Employee>();
            //string ExpectedExceptionMessage = String.Format("");
            //Employee PM2 = new Programmer("", "", 0);

            //act
            //testEmployees.Add(null);
            //NullReferenceException exception = Assert.Throws<Exception>()) => Hometask.Add(null);
            //testDep.Add(new Programmer("", null, 40));
            //var ex = Assert.Throws<NullReferenceException>(() => testEmployees.Add(null));

            //assert
            //Assert.Throws(Is.TypeOf<NullReferenceException>())
            //    .And.Message.EqualTo("message")
            //    .And.Property()
            //Assert.Throws<NullReferenceException>()) => testEmployees.Add(null);
            //var ex = Assert.Throws<NullReferenceException>( delegate {throw new  testEmployees.Add(null));
            //Assert.That(ex.Message, Is.EqualTo("Ссылка на объект не указывает на экземпляр объекта."));


        }

        [Test]
        public void Add_WrongAge_ShouldThrowArgumentException()
        {
            //arrange
            List<Employee> testEmployees = new List<Employee>();
            Employee youngEmployee = new Programmer("Bella", "Swan", 15);
            
            //act
            testEmployees.Add(youngEmployee);

            //assert
            Assert.Throws(Is.TypeOf<ArgumentException>()
                .And.Message.EqualTo("Значение не попадает в ожидаемый диапазон")
                .And.Property("Age").EqualTo("15"),
            delegate { throw new ArgumentException("Значение не попадает в ожидаемый диапазон", "15"); });
        }

        [Test]
        public void Sort_ShouldSortByAge()
        {
            //arrange
            List<Employee> employees = new List<Employee>();
            Employee javaDev = new Programmer("Ron", "Johnson", 25);
            Employee pythonDev = new Programmer("Isabella", "Johnson", 21);
            Employee manager = new Programmer("Patrick", "Wattington", 55);
            employees.Add(javaDev);
            employees.Add(pythonDev);
            employees.Add(manager);
            Department testDep = new Department();
            testDep.Add(javaDev);
            testDep.Add(pythonDev);
            testDep.Add(manager);
            employees.Sort();
            //testDep.Add(new Manager("Alice", "Hoogan", 30));
            //testDep.Add(new Programmer("Bob", "Marley", 40));
            //testDep.Add(new Programmer("Jack", "Lampard", 31));

            //string expectedMessage = String.Format("My name is {0}, my last name is {1}, my age is {2}", testDep);

            List<Employee> expectedCollection = new List<Employee> { pythonDev, javaDev, manager };
            //int expectedSize = 3;
            //act
            testDep.Sort();

            //assert
           // Assert.That(testDep, Has.Count.EqualTo(expectedSize));
            //Assert.AreEqual(expectedMessage, Is.
            //Assert.That(testDep, Is.EquivalentTo(expectedCollection));
            Assert.That(employees, Is.EqualTo(expectedCollection));

        }

        [Test]
        public void GetAll_ValidData_ShouldContain3Employees()
        {
            //arrange
            List<Employee> employees = new List<Employee>();
            Employee javaDev = new Programmer("Ron", "Johnson", 25);
            Employee pythonDev = new Programmer("Isabella", "Johnson", 21);
            Employee manager = new Programmer("Patrick", "Wattington", 55);
            employees.Add(javaDev);
            employees.Add(pythonDev);
            employees.Add(manager);
            Department testDep = new Department();
            foreach (Employee emp in employees)
            {
                testDep.Add(emp);
            }
            //testDep.Add(javaDev);
            //testDep.Add(pythonDev);
            //testDep.Add(manager);

            //act
            testDep.GetAll();
            int expectedCount = employees.Count;
            //string expectedMessage = String.Format("My name is {0}, my last name is {1}, my age is {2}", testDep);

            //assert
            Assert.AreEqual(expectedCount, testDep.GetAll().Count);
            //Assert.That(expectedMessage, Does.Contain(testDep.GetAll()));
        }

        
    }
}
