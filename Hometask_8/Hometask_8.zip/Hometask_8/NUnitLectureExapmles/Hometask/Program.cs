﻿namespace Hometask
{
    using System;
    using System.Collections.Generic;

    public class Program
    {
        static void Main(string[] args)
        {
            Department department = new Department();

            department.Add(new Manager("Hugh", "Allard", 35));
            department.Add(new Manager("Adam", "Ellard", 21));
            department.Add(new Manager("Alice", "Ahoogan", 21));
            department.Add(new Programmer("Bob", "Marley", 40));
            department.Add(new Programmer("Jack", "Ellard", 21));


            //department.Add( new Programmer("Ronn", "Johnson", 21));

            //department.Add(new Programmer("Patrick", "Wattington", 21));
            //department.Add(new Programmer("Anna", "Johnson", 21));

            Console.WriteLine("List of employees before sort()");
            ShowAllEmployees(department.GetAll());

            department.Sort();

            Console.WriteLine("List of employees after sort()");
            ShowAllEmployees(department.GetAll());

            Console.ReadKey();
        }

        public static void ShowAllEmployees(List<Employee> employees)
        {
            for (int i = 0; i < employees.Count; i++)
            {
                Console.WriteLine(employees[i].ToString());
            }
        }
    }
}
