﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask
{
    public class Car: IComparable<Car>
    {
        public string Name { get; set; }
        public int Speed { get; set; }
        public string Color { get; set; }

        List<Car> cars = new List<Car>();

        public int CompareTo(Car other)
        {
            // Determine the relative order of the objects being compared.  
            // Sort by color alphabetically, and then by speed in  
            // descending order.  

            // Compare the colors.  
            int compare;
            compare = String.Compare(this.Color, other.Color, true);

            // If the colors are the same, compare the speeds.  
            if (compare == 0)
            {
                compare = this.Speed.CompareTo(other.Speed);

                // Use descending order for speed.  
                compare = -compare;
            }

            return compare;
        }

        public override bool Equals(object obj)
        {
            var car = obj as Car;
            return Color == car.Color && Speed == car.Speed && Name == car.Name;
             
        }

        public void Sort()
        {
            cars.Sort();
        }


    }

}

