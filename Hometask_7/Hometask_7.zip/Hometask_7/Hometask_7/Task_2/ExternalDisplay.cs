﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    public class ExternalDisplay : IDisplay
    {
        public void Display(string text)
        {
            Console.WriteLine(text);
        }
    }
}
