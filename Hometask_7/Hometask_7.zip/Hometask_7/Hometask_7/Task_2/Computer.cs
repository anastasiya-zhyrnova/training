﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    public class Computer : IInput, IDisplay, IProcess
    {
        private IInput _inputType;
        private IDisplay _displayType;
        private IProcess _processorType;
 
        public Computer(IInput inputType, IDisplay displayType, IProcess processorType) 
        {
            _inputType = inputType;
            _displayType = displayType;
            _processorType = processorType;
        }

        public void Work()
        {
            _inputType.GetInput();
            _displayType.Display("Display this!");
            _processorType.Process("This process has started.... ");
            
        }

        public string GetInput()
        {
            return _inputType.GetInput();
        }

        public void Display(string text)
        {
            _displayType.Display("some text");
        }

        public void Process(string process)
        {
            _processorType.Process("some text");
        }
    }
}
