﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    public class Joystick : IInput
    {
        public string GetInput()
        {
            string input = Console.ReadLine();
            return input;
        }
    }
}
