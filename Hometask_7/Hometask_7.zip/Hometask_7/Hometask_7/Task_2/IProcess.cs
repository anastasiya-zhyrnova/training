﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    public interface IProcess
    {
        void Process(string process);
    }
}
