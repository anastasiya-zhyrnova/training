﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    public class Book
    {
        private readonly Author _nameSurname;
        private readonly string _bookName;
        private readonly string _text;

        public Book(Author nameSurname, string bookName, string text) 
        {
            _nameSurname = nameSurname;
            _bookName = bookName;
            _text = text;
        }

        public override string ToString()
        {
            string result = _nameSurname.ToString() + " " + "\r\n" + "Book name is: " + '\"' + _bookName + '\"'; 
            return result;
        }

    }
}
