﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    public class Author
    {
        private readonly string _name;
        private readonly string _surname;

        public Author(string name, string surname)
        {
            _name = name;
            _surname = surname;
    
        }

        public override string ToString()
        {
            return @"Author name is: " + _name + " "  + "Author surname is: " + _surname;
        }
    }
}
