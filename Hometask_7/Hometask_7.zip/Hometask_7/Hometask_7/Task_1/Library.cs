﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    public class Library
    {
        List<Book> _books = new List<Book>();

        public Library(List<Book> books)
        {
            _books = books;
        }

        public void DisplayBooks()
        {
            foreach (Book book in _books)
            {
                Console.WriteLine(book.ToString());
            }
        }
    }
}
