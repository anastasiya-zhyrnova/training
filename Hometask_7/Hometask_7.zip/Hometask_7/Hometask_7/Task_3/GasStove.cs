﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    public class GasStove : ICook, IBake
    {
        private GasCooktop _stoveUp = new GasCooktop();
        private GasOven _stoveDown = new GasOven();

        public GasStove(GasCooktop gasCooktop, GasOven gasOven)
        {
            _stoveUp = gasCooktop;
            _stoveDown = gasOven;
        }

        public void Cook()
        {
            _stoveUp.Cook();
        }

        public void Bake()
        {
            _stoveDown.Bake();
        }
    }
}
