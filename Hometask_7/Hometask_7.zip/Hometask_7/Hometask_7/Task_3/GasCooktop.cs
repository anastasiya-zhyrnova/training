﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    public class GasCooktop : ICook
    {
        public void Cook()
        {
            Console.WriteLine("Give us some gas!");
        }
    }
}
