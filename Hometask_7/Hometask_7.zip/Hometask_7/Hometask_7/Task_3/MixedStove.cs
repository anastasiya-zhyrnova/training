﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    class MixedStove
    {
        private ElectricCooktop _electrCooktop;
        private GasCooktop _gasCookTop;
        private ElectricOven _electrOven;
        private GasOven _gasOven;

        public MixedStove(ElectricCooktop cooktop, GasOven oven)
        {
            _electrCooktop = cooktop;
            _gasOven = oven;
        }

        public MixedStove(GasCooktop cooktop, ElectricOven oven)
        {
            _gasCookTop = cooktop;
            _electrOven = oven;

        }

        public void Cook()
        {
            try
            {
                _electrCooktop.Cook();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception catched");
            }
            finally
            {
                _gasCookTop.Cook();
            }
        }

        public void Bake()
        {
            try
            {
                _gasOven.Bake();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception catched");
            }
            finally
            {
                _electrOven.Bake();
            }
            
        }



    }
}
