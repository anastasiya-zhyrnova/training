﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    public class ElectricStove : ICook, IBake
    {
        private ElectricCooktop _stoveUp = new ElectricCooktop();
        private ElectricOven _stoveDown = new ElectricOven();

        public ElectricStove(ElectricCooktop cooktop, ElectricOven oven)
        {
            _stoveUp = cooktop;
            _stoveDown = oven;
        }

        public void Cook()
        {
            _stoveUp.Cook();
        }

        public void Bake()
        {
            _stoveDown.Bake();
        }
    }
}
