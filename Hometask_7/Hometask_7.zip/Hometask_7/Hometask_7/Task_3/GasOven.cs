﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    public class GasOven : IBake
    {
        public void Bake()
        {
            Console.WriteLine("You can bake cakes, cookies and much more with me");
        }
    }
}
