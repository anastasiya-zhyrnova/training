﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hometask_7
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Task_1
            //Author ConanDoyle = new Author("Arthur", "Conan Doyle");
            //Author Christie = new Author("Agatha", "Christie");
            //Book book1 = new Book(ConanDoyle, "Adventures of Sherlock Holmes", "some text");
            //Book book2 = new Book(Christie, "The Murder in the Orient Express", "text text text");
            //List<Book> myBooks = new List<Book>();
            //myBooks.Add(book1);
            //myBooks.Add(book2);
            //Library myLibrary = new Library(myBooks);
            //myLibrary.DisplayBooks();

            #endregion
            #region Task_2
            Keyboard k = new Keyboard();
            ExternalDisplay d = new ExternalDisplay();
            Amd64Processor p = new Amd64Processor();
            Computer computer = new Computer(k, d, p);
            computer.Work();
            #endregion

            #region Task_3
            ElectricCooktop elTop = new ElectricCooktop();
            GasCooktop gasTop = new GasCooktop();
            ElectricOven elOven = new ElectricOven();
            GasOven gasOven = new GasOven();
            ElectricStove elStove = new ElectricStove(elTop, elOven);
            GasStove gasStove = new GasStove(gasTop, gasOven);
            MixedStove luxuryStove_1 = new MixedStove(elTop, gasOven);
            MixedStove luxuryStove_2 = new MixedStove(gasTop, elOven);

            gasOven.Bake();
            gasTop.Cook();

            elStove.Cook();
            elStove.Bake();

            gasStove.Cook();
            gasStove.Bake();

            luxuryStove_1.Cook();
            luxuryStove_1.Bake();

            luxuryStove_2.Cook();
            luxuryStove_2.Bake();
            
            

            #endregion
            Console.ReadKey();
        }
    }
}
